<?php
session_start();
require_once 'db.php'; // รวมไฟล์ที่เชื่อมต่อฐานข้อมูล

// ตรวจสอบการล็อกอิน
if (!isset($_SESSION['user_login']) && !isset($_SESSION['admin_login'])) {
    header("Location: signin.php"); // หากไม่ได้ล็อกอินให้ส่งกลับไปยังหน้าเข้าสู่ระบบ
    exit();
}

// ตรวจสอบสิทธิ์ของผู้ใช้
$userId = isset($_SESSION['user_login']) ? $_SESSION['user_login'] : $_SESSION['admin_login'];

// ดึงข้อมูลผู้ใช้จากฐานข้อมูล
try {
    $stmt = $conn->prepare("SELECT * FROM users WHERE id = :id");
    $stmt->bindParam(":id", $userId);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
    exit();
}

// หากไม่พบข้อมูลผู้ใช้
if (!$user) {
    echo "ไม่พบข้อมูลผู้ใช้";
    exit();
}
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ข้อมูลผู้ใช้</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/5.3.0/css/bootstrap.min.css">
    <style>
        body, html {
            margin: 0;
            padding: 0;
            height: 100%;
            font-family: Arial, sans-serif;
            color: #495057;
            overflow: hidden; /* ซ่อนการเลื่อนเพื่อให้วีดีโอพื้นหลังแสดงผลได้เต็มที่ */
        }

        .video-bg {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            object-fit: cover;
            z-index: -1;
            filter: brightness(60%); /* ลดความสว่างของวีดีโอ */
        }

        .container {
            max-width: 600px;
            margin: 30px auto;
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            position: relative; /* ทำให้คอนเทนเนอร์อยู่เหนือวีดีโอพื้นหลัง */
            z-index: 1;
            text-align: center; /* จัดกึ่งกลางเนื้อหา */
        }

        h1 {
            margin-bottom: 20px;
            color: #007bff;
        }

        .profile-info {
            margin-bottom: 20px;
        }

        .profile-info label {
            font-weight: bold;
            display: block;
            margin-bottom: 5px;
            color: #343a40;
        }

        .profile-info p {
            margin: 0;
            padding: 10px;
            background-color: #f1f3f5;
            border-radius: 5px;
        }

        .profile-picture {
            border-radius: 50%;
            border: 4px solid #007bff; /* กรอบรูปภาพ */
            margin-bottom: 20px;
            width: 150px; /* ขนาดรูปภาพ */
            height: 150px; /* ขนาดรูปภาพ */
            object-fit: cover; /* ทำให้รูปภาพพอดีกับกรอบ */
        }

        .btn {
            display: inline-block;
            padding: 10px 20px;
            font-size: 16px;
            color: #ffffff;
            background-color: #28a745;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            text-align: center;
        }

        .btn:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>
    <video autoplay muted loop class="video-bg">
        <source src="mylivewallpapers-com-Muzan-Kibutsuji-4K.mp4" type="video/mp4">
    </video>
    <div class="container">
        <h1>ข้อมูลผู้ใช้</h1>
        <div class="profile-info">
            <label>ชื่อ:</label>
            <p><?php echo htmlspecialchars($user['firstname']); ?></p>
            <label>อีเมล:</label>
            <p><?php echo htmlspecialchars($user['email']); ?></p>
            <label>บทบาท:</label>
            <p><?php echo htmlspecialchars($user['urole']); ?></p>
            <!-- เพิ่มข้อมูลอื่น ๆ ตามที่ต้องการ -->
        </div>
        <a href="logout.php" class="btn">ออกจากระบบ</a>
    </div>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>
</html>
