<?php 
    session_start();
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Kanit:wght@300;400;700&display=swap">
    <title>สวัสดีจ้า</title>
    <style>
        body {
            background-image: url(m.jpg);
            padding: 60px;
            font-family: 'Kanit', sans-serif; /* ใช้ฟอนต์ Kanit */
            color: #333; /* สีตัวอักษรพื้นฐาน */
        }
        .content {
            margin: 0 auto;
            padding: 20px;
            background-color: rgba(255, 255, 255, 0.9);
            border-radius: 10px;
            max-width: 800px; /* จำกัดความกว้าง */
        }
        h1 {
            color: #E1AFD1;
            font-size: 2.5rem; /* ขนาดตัวอักษรใหญ่ขึ้น */
            margin-bottom: 20px;
        }
        h2 {
            color: #333;
            font-size: 1.25rem; /* ขนาดตัวอักษรเล็กลงเล็กน้อย */
            margin-bottom: 15px;
        }
        .profile {
            text-align: center;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
        }
        .profile img {
            margin-bottom: 20px;
            width: 150px;
            height: 200px;
            border: 10px solid transparent;
            border-image: url('กรอบทอง.png') 75 round;
            border-radius: 10px;
        }
        .video-bg {
            position: fixed;
            top: 0;
            left: 0;
            min-width: 100%;
            min-height: 100%;
            z-index: -1;
        }
        .navbar {
            background-color: rgba(0, 0, 0, 0.5);
        }
        .navbar-brand {
            font-weight: bold;
        }
        .footer {
            background-color: rgba(0, 0, 0, 0.5);
            padding: 20px;
            text-align: center;
            color: white;
            margin-top: 20px;
            font-size: 0.875rem;
        }
        .icon {
            margin-right: 8px; /* ระยะห่างระหว่างไอคอนกับข้อความ */
        }
    </style>
</head>
<body>

<video autoplay muted loop class="video-bg">
    <source src="mylivewallpapers-com-Cute-Sagiri-Izumi-FHD.mp4" type="video/mp4">
</video>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="#">หน้าหลัก</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">เกี่ยวกับ</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">ติดต่อ</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="container-fluid p-5 text-white text-center">
    <h1>รายชื่อนักเรียนนักศึกษาห้อง D5</h1>
</div>

<div class="content">
  <div class="profile">
    <img src="keeact V.2.jpg" alt="Trulli">
    <div>
        <h1>ประวัติส่วนตัว</h1>
        <h2>นาย รัฐภูมิ คนเพียร ชื่อเล่น ฟิล์ม</h2>
        <h2>อายุ 18 ขวบ แผนก IT ห้อง D5</h2>
        <h2>ที่อยู่: 113 หมู่ 10 บ้านหนองหอย ตำบลกุดชุมแสง อำเภอหนองบัวแดง จังหวัดชัยภูมิ</h2>
        <h2>เกี่ยวกับฉัน: ชื่อฟิล์ม เรียกฟิล์มนั่นแหละ ชอบเล่นเกม และชอบนอนเป็นพิเศษ</h2>
        <h2>กรุ๊บเลือด: ไม่ทราบ</h2>
        <h2>วัน/เดือน/ปีเกิด: 31/5/2548</h2>
        <h1>ช่องทางติดต่อ :</h1>
        <h2><i class="fab fa-facebook icon"></i> FB: Rattaphun Konpiean</h2>
        <h2><i class="fas fa-envelope icon"></i> Gmail: Fim36210@gmail.com</h2>
        <h2><i class="fas fa-phone icon"></i> Tel: 0653150450</h2>
        <h1>ชื่อบิดา มารดา :</h1>
        <h2>ชื่อบิดา: นายโส คนเพียร อาชีพ: รับจ้าง อายุ: 37 เบอร์: 0929691564</h2>
        <h2>ชื่อมารดา: นางสาวประนอม สุนิพรม อาชีพ: รับจ้าง อายุ: 40 เบอร์: 0929691564</h2>
        <h1>ประวัติการศึกษา</h1>
        <h2>จบประถมศึกษาจาก โรงเรียนบ้านหนองหอย</h2>
        <h2>จบมัธยมศึกษาตอนต้นจาก โรงเรียนหนองบัวแดงวิทยา</h2>
        <h2>จบมัธยมศึกษาตอนปลายจาก โรงเรียนหนองบัวแดงวิทยา</h2>
        <h1>คติประจำใจ</h1>
        <h2>ความอดทนจะเปลี่ยนคนให้แข็งแกร่ง</h2>
        <h1>งานอดิเรก</h1>
        <h2>นอน</h2>
        <h1>เลือกสาขานี้เพราะอะไร</h1>
        <h2>อยากทำงานสายไอที</h2>
    </div>
    </div>
    
</div>

<div class="footer">
    <p>&copy; 2024 Rattaphun Konpiean. All Rights Reserved.</p>
</div>

</body>
</html>
