<?php 

    session_start();
    require_once 'db.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ล็อคอินเข้าสู่ระบบ</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login for singel peple</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
        crossorigin="anonymous"></script>
</head>
<body>
    <style>
        body {
           display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 100px;
            background-image: url('22.png');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
}
      
 .right-content {
            background-image: url(zzzผัววววว.jpg);
            background-size: cover;
            background-position: center;
            height: 100%;
            border-top-right-radius: 20px;
            border-bottom-right-radius: 20px;
        }
    .hr {
        display: flex;
        align-items: center;
        text-align: center;
    }

    .hr ::before .hr ::after {
        content: '';
        flex: 1;
        border-bottom: 1px solid ;
    }

    .hr ::before {
        margin-right: 10px;
    }

    .hr ::after {
        margin-left: 10px;
    }

   

    body {
        font-family: "Mulish , sans-serif";
        font-weight: 500;

    }

    .btn-login {
        border-radius: 3px;
        color: rgb(22, 113, 143);
        background-image: linear-gradient(to right, #877bdc, #8023e3, #781aea#6e0ef1, #6100f8);

    }

    .btn-login.hover {
        background-image: none;
        border: 1px solid rgb(129, 72, 72);
    }
</style>
<body>
   
        <div class="container">
            <div class="content d-flex justify-content-center align-items-center vh-25">
                <div class="card border-50 shadow-lg w-75 p-3" style=" height: 50%; border-radius: 25px;">
                    <div class="card-body">
                        <div class="row h-50">
                            <div class="col-md-50 d-flex align-items-center">
                                <div class="left-content text-center w-75 m-auto "></div>
    <div class="container">
        <h3 class="mt-4">สมัครสมาชิก</h3>
        <hr>
        <form action="signup_db.php" method="post">
            <?php if(isset($_SESSION['error'])) { ?>
                <div class="alert alert-danger" role="alert">
                    <?php 
                        echo $_SESSION['error'];
                        unset($_SESSION['error']);
                    ?>
                </div>
            <?php } ?>
            <?php if(isset($_SESSION['success'])) { ?>
                <div class="alert alert-success" role="alert">
                    <?php 
                        echo $_SESSION['success'];
                        unset($_SESSION['success']);
                    ?>
                </div>
            <?php } ?>
            <?php if(isset($_SESSION['warning'])) { ?>
                <div class="alert alert-warning" role="alert">
                    <?php 
                        echo $_SESSION['warning'];
                        unset($_SESSION['warning']);
                    ?>
                </div>
            <?php } ?>

            <div class="mb-3">
                <label for="firstname" class="form-label">First name</label>
                <input type="text" class="form-control" name="firstname" aria-describedby="firstname">
            </div>
            <div class="mb-3">
                <label for="lastname" class="form-label">Last name</label>
                <input type="text" class="form-control" name="lastname" aria-describedby="lastname">
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" name="email" aria-describedby="email">
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" class="form-control" name="password">
            </div>
            <div class="mb-3">
                <label for="confirm password" class="form-label">Confirm Password</label>
                <input type="password" class="form-control" name="c_password">
            </div>
            <button type="submit" name="signup" class="btn btn-primary">Sign Up</button>
        </form>
        <hr>
        <p>เป็นสมาชิกแล้วใช่ไหม คลิ๊กที่นี่เพื่อ <a href="signin.php">เข้าสู่ระบบ</a></p>
    </div>
    
</body>
</html>